import { type TimeSeriesSelectOptions } from './time-series-select-options.ts';
import { normalizeTimeSeriesTimeRangeOptions } from '../../time-range/normalized-time-series-time-range-options.ts';

export type NormalizedTimeSeriesSelectOptions = Required<TimeSeriesSelectOptions>;

export function normalizeTimeSeriesSelectOptions({
  asc = true,
  ...options
}: TimeSeriesSelectOptions | undefined = {}): NormalizedTimeSeriesSelectOptions {
  return {
    ...normalizeTimeSeriesTimeRangeOptions(options),
    asc,
  };
}

import { type TimeSeriesTimeRangeOptions } from '../../time-range/time-series-time-range-options.ts';

export interface TimeSeriesSelectOptions extends TimeSeriesTimeRangeOptions {
  readonly asc?: boolean;
}

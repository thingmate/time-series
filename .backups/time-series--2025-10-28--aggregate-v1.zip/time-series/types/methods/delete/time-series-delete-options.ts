import { type TimeSeriesTimeRangeOptions } from '../../time-range/time-series-time-range-options.ts';

export interface TimeSeriesDeleteOptions extends TimeSeriesTimeRangeOptions {}

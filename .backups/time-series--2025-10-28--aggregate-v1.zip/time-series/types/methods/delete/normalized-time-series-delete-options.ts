import { normalizeTimeSeriesTimeRangeOptions } from '../../time-range/normalized-time-series-time-range-options.ts';
import { type TimeSeriesDeleteOptions } from './time-series-delete-options.ts';

export type NormalizedTimeSeriesDeleteOptions = Required<TimeSeriesDeleteOptions>;

export function normalizeTimeSeriesDeleteOptions(
  options: TimeSeriesDeleteOptions | undefined,
): NormalizedTimeSeriesDeleteOptions {
  return normalizeTimeSeriesTimeRangeOptions(options);
}

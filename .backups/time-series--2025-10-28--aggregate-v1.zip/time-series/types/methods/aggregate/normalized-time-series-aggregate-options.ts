import {
  type NormalizedTimeSeriesTimeRangeOptions,
  normalizeTimeSeriesTimeRangeOptions,
} from '../../time-range/normalized-time-series-time-range-options.ts';
import { type TimeSeriesAggregateMode } from './time-series-aggregate-mode.ts';
import { type TimeSeriesAggregateOptions } from './time-series-aggregate-options.ts';
import type { TimeSeriesAggregateTime } from './time-series-aggregate-time.ts';

export type NormalizedTimeSeriesAggregateOptions = Required<TimeSeriesAggregateOptions>;

const VALID_TIME_SERIES_AGGREGATE_MODES: ReadonlySet<TimeSeriesAggregateMode> =
  new Set<TimeSeriesAggregateMode>(['average-time-weighted', 'concat']);

const VALID_TIME_SERIES_AGGREGATE_TIME: ReadonlySet<TimeSeriesAggregateTime> =
  new Set<TimeSeriesAggregateTime>(['start', 'end', 'average']);

export function normalizeTimeSeriesAggregateOptions({
  mode,
  time = 'average',
  ...options
}: TimeSeriesAggregateOptions): NormalizedTimeSeriesAggregateOptions {
  const normalizedTimeSeriesTimeRangeOptions: NormalizedTimeSeriesTimeRangeOptions =
    normalizeTimeSeriesTimeRangeOptions(options);

  if (!VALID_TIME_SERIES_AGGREGATE_MODES.has(mode)) {
    throw new Error(
      `Invalid aggregate mode: ${mode}, expected one of: ${Array.from(VALID_TIME_SERIES_AGGREGATE_MODES).join(', ')}.`,
    );
  }

  if (
    !VALID_TIME_SERIES_AGGREGATE_TIME.has(time) &&
    (typeof time !== 'number' ||
      !Number.isSafeInteger(time) ||
      time < normalizedTimeSeriesTimeRangeOptions.from ||
      time > normalizedTimeSeriesTimeRangeOptions.to)
  ) {
    throw new Error(
      `Invalid aggregate time: ${time}, expected one of: ${Array.from(VALID_TIME_SERIES_AGGREGATE_TIME).join(', ')} OR integer if range [${normalizedTimeSeriesTimeRangeOptions.from}, ${normalizedTimeSeriesTimeRangeOptions.to}].`,
    );
  }

  return {
    ...normalizeTimeSeriesTimeRangeOptions(options),
    mode,
    time,
  };
}

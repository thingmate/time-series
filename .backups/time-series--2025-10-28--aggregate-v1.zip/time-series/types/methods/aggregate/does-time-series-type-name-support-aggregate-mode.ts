import { type TimeSeriesTypeName } from '../../time-series-types-map.ts';
import { type TimeSeriesAggregateMode } from './time-series-aggregate-mode.ts';

const TIME_SERIES_TYPE_NUMBER_TO_SUPPORTED_AGGREGATE_MODE_MAP: ReadonlySet<TimeSeriesAggregateMode> =
  new Set<TimeSeriesAggregateMode>(['average-time-weighted']);

const TIME_SERIES_TYPE_NAME_TO_SUPPORTED_AGGREGATE_MODE_MAP: Record<
  TimeSeriesTypeName,
  ReadonlySet<TimeSeriesAggregateMode>
> = {
  int64: TIME_SERIES_TYPE_NUMBER_TO_SUPPORTED_AGGREGATE_MODE_MAP,
  float64: TIME_SERIES_TYPE_NUMBER_TO_SUPPORTED_AGGREGATE_MODE_MAP,
  text: new Set<TimeSeriesAggregateMode>(['concat']),
  any: new Set<TimeSeriesAggregateMode>([]),
};

export function doesTimeSeriesTypeNameSupportAggregateMode(
  type: TimeSeriesTypeName,
  mode: TimeSeriesAggregateMode,
): boolean {
  return TIME_SERIES_TYPE_NAME_TO_SUPPORTED_AGGREGATE_MODE_MAP[type].has(mode);
}

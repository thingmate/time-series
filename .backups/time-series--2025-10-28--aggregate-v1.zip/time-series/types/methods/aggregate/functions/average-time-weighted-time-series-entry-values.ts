import { type TimeSeriesEntry } from '../../../time-series-entry.ts';
import { type TimeSeriesTypeName } from '../../../time-series-types-map.ts';

export function averageTimeWeightedTimeSeriesEntryValues<
  GTypeName extends Extract<TimeSeriesTypeName, 'int64' | 'float64'>,
>(type: GTypeName, entries: readonly TimeSeriesEntry<GTypeName>[]): number {
  let weightedSum: number = 0;
  let totalTime: number = 0;

  for (let i: number = 0; i < entries.length; i += 1) {
    const { time, value } = entries[i];
    weightedSum += time * value;
    totalTime += time;
  }

  weightedSum /= totalTime;

  return type === 'int64' ? Math.round(weightedSum) : weightedSum;
}

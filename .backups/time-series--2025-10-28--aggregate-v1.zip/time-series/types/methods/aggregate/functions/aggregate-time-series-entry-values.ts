import { type TimeSeriesEntry } from '../../../time-series-entry.ts';
import {
  type InferTimeSeriesType,
  type TimeSeriesTypeName,
} from '../../../time-series-types-map.ts';
import { type TimeSeriesAggregateMode } from '../time-series-aggregate-mode.ts';
import { averageTimeWeightedTimeSeriesEntryValues } from './average-time-weighted-time-series-entry-values.ts';
import { concatTimeSeriesEntryValues } from './concat-time-series-entry-values.ts';

export function aggregateTimeSeriesEntryValues<GTypeName extends TimeSeriesTypeName>(
  type: GTypeName,
  entries: readonly TimeSeriesEntry<GTypeName>[],
  mode: TimeSeriesAggregateMode,
): InferTimeSeriesType<GTypeName> {
  switch (mode) {
    case 'average-time-weighted':
      return averageTimeWeightedTimeSeriesEntryValues<Extract<GTypeName, 'int64' | 'float64'>>(
        type as Extract<GTypeName, 'int64' | 'float64'>,
        entries,
      );
    case 'concat':
      return concatTimeSeriesEntryValues(entries);
    default:
      throw new Error(`Invalid aggregate mode: ${mode}.`);
  }
}

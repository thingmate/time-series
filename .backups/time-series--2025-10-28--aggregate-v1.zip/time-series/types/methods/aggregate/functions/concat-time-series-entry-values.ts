import { type TimeSeriesEntry } from '../../../time-series-entry.ts';

export function concatTimeSeriesEntryValues(
  entries: readonly TimeSeriesEntry<'text'>[],
  separator: string = '\n',
): string {
  let concatenated: string = '';

  for (let i: number = 0; i < entries.length; i += 1) {
    const { value } = entries[i];

    if (i !== 0) {
      concatenated += separator;
    }

    concatenated += value;
  }

  return concatenated;
}

// export type TimeSeriesAggregateMode = 'sum' | 'avg' | 'med' | 'min' | 'max' | 'concat';

export type TimeSeriesAggregateMode = 'average-time-weighted' | 'concat';

export type TimeSeriesAggregateTime = 'start' | 'end' | 'average' | number;

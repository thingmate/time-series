import { type TimeSeriesTimeRangeOptions } from '../../time-range/time-series-time-range-options.ts';
import { type TimeSeriesAggregateMode } from './time-series-aggregate-mode.ts';
import { type TimeSeriesAggregateTime } from './time-series-aggregate-time.ts';

export interface TimeSeriesAggregateOptions extends TimeSeriesTimeRangeOptions {
  readonly mode: TimeSeriesAggregateMode;
  readonly time?: TimeSeriesAggregateTime;
}

import { type InferTimeSeriesType, type TimeSeriesTypeName } from './time-series-types-map.ts';

export interface TimeSeriesEntry<GTypeName extends TimeSeriesTypeName> {
  readonly time: number;
  readonly value: InferTimeSeriesType<GTypeName>;
}

export interface TimeSeriesTimeRangeOptions {
  readonly from?: number;
  readonly to?: number;
}

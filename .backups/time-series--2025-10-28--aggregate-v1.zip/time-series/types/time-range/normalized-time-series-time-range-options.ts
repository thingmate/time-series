import { type TimeSeriesTimeRangeOptions } from './time-series-time-range-options.ts';

export type NormalizedTimeSeriesTimeRangeOptions = Required<TimeSeriesTimeRangeOptions>;

export function normalizeTimeSeriesTimeRangeOptions({
  from = Number.NEGATIVE_INFINITY,
  to = Number.POSITIVE_INFINITY,
}: TimeSeriesTimeRangeOptions | undefined = {}): NormalizedTimeSeriesTimeRangeOptions {
  if (
    typeof from !== 'number' ||
    (from !== Number.NEGATIVE_INFINITY && !Number.isSafeInteger(from))
  ) {
    throw new Error('"from" must be an integer in range [-Infinity, +Infinity[.');
  }

  if (
    typeof to !== 'number' ||
    (to !== Number.POSITIVE_INFINITY && !Number.isSafeInteger(to)) ||
    to < from
  ) {
    throw new Error('"to" must be an integer in range [from, +Infinity].');
  }

  return {
    from,
    to,
  };
}

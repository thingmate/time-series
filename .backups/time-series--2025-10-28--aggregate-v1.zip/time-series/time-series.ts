import { doesTimeSeriesTypeNameSupportAggregateMode } from './types/methods/aggregate/does-time-series-type-name-support-aggregate-mode.ts';
import { aggregateTimeSeriesEntryValues } from './types/methods/aggregate/functions/aggregate-time-series-entry-values.ts';
import { normalizeTimeSeriesAggregateOptions } from './types/methods/aggregate/normalized-time-series-aggregate-options.ts';
import { type TimeSeriesAggregateOptions } from './types/methods/aggregate/time-series-aggregate-options.ts';
import { type TimeSeriesDeleteOptions } from './types/methods/delete/time-series-delete-options.ts';
import { type TimeSeriesSelectOptions } from './types/methods/select/time-series-select-options.ts';
import { type TimeSeriesEntry } from './types/time-series-entry.ts';
import {
  type InferTimeSeriesType,
  type TimeSeriesTypeName,
} from './types/time-series-types-map.ts';

export abstract class TimeSeries<GTypeName extends TimeSeriesTypeName> implements Disposable {
  readonly #typeName: GTypeName;

  protected constructor(typeName: GTypeName) {
    this.#typeName = typeName;
  }

  get typeName(): GTypeName {
    return this.#typeName;
  }

  abstract insert(entries: readonly TimeSeriesEntry<GTypeName>[]): void;

  push(time: number, value: InferTimeSeriesType<GTypeName>): void {
    this.insert([{ time, value }]);
  }

  abstract select(options?: TimeSeriesSelectOptions): TimeSeriesEntry<GTypeName>[];

  abstract delete(options?: TimeSeriesDeleteOptions): void;

  aggregate(options: TimeSeriesAggregateOptions): TimeSeriesEntry<GTypeName> | null {
    const { mode, time, from, to } = normalizeTimeSeriesAggregateOptions(options);

    if (!doesTimeSeriesTypeNameSupportAggregateMode(this.typeName, mode)) {
      throw new Error(`The type "${this.typeName}" does not support the "${mode}" aggregate mode.`);
    }

    const entries: readonly TimeSeriesEntry<GTypeName>[] = this.select({ from, to });

    if (entries.length === 0) {
      return null;
    }

    const startTime: number = entries[0].time;
    const endTime: number = entries[entries.length - 1].time;

    const aggregatedEntry: TimeSeriesEntry<GTypeName> = {
      time:
        time === 'start'
          ? startTime
          : time === 'end'
            ? endTime
            : Math.round((startTime + endTime) / 2),
      value: aggregateTimeSeriesEntryValues(this.typeName, entries, mode),
    };

    return aggregatedEntry;
  }

  abstract drop(): void;

  abstract [Symbol.dispose](): void;
}

// { time, mode }: Pick<NormalizedTimeSeriesAggregateOptions, 'mode' | 'time'>,
// TimeSeriesEntry<TimeSeriesTypeName>

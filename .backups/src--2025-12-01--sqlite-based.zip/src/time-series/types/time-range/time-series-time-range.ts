export interface TimeSeriesTimeRange {
  readonly from: number;
  readonly to: number;
}

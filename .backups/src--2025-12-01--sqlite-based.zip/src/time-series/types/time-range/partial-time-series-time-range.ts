import { type TimeSeriesTimeRange } from './time-series-time-range.ts';

export type PartialTimeSeriesTimeRange = Partial<TimeSeriesTimeRange>;

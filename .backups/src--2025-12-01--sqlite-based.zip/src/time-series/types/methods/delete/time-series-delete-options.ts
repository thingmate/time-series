import { type PartialTimeSeriesTimeRange } from '../../time-range/partial-time-series-time-range.ts';

export interface TimeSeriesDeleteOptions extends PartialTimeSeriesTimeRange {}

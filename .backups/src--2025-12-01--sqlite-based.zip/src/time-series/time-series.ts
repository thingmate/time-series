import { type AggregatedTimeSeriesEntry } from './types/methods/aggregate/aggregated-time-series-entry.ts';
import { normalizeTimeSeriesAggregateOptions } from './types/methods/aggregate/normalized-time-series-aggregate-options.ts';
import { type TimeSeriesAggregateConcatOptions } from './types/methods/aggregate/time-series-aggregate-concat-options.ts';
import { type TimeSeriesAggregateOptions } from './types/methods/aggregate/time-series-aggregate-options.ts';
import { type TimeSeriesAggregator } from './types/methods/aggregate/time-series-aggregator.ts';
import { type TimeSeriesDeleteOptions } from './types/methods/delete/time-series-delete-options.ts';
import { type TimeSeriesSelectOptions } from './types/methods/select/time-series-select-options.ts';
import { type TimeSeriesTimeRange } from './types/time-range/time-series-time-range.ts';
import { type TimeSeriesEntry } from './types/time-series-entry.ts';
import {
  type InferTimeSeriesType,
  type TimeSeriesTypeName,
} from './types/time-series-types-map.ts';

export type TimeSeriesDates = readonly number[];

export interface TimeSeriesEveryOptions extends TimeSeriesTimeRange {
  readonly step: number;
}

export abstract class TimeSeries<GTypeName extends TimeSeriesTypeName> implements Disposable {
  static repeat(dates: TimeSeriesDates, callback: (timeRange: TimeSeriesTimeRange) => void): void {
    for (let i: number = 0, l: number = dates.length - 1; i < l; i++) {
      const from: number = dates[i];
      const to: number = dates[i + 1];

      if (from > to) {
        throw new Error(`Invalid time range at #${i}: [${from}, ${to}].`);
      }

      callback({ from, to });
    }
  }

  static every({ from, to, step }: TimeSeriesEveryOptions): TimeSeriesDates {
    return Array.from({ length: Math.floor((to - from) / step) }, (_, index: number): number => {
      return from + index * step;
    });
  }

  readonly #typeName: GTypeName;

  protected constructor(typeName: GTypeName) {
    this.#typeName = typeName;
  }

  get typeName(): GTypeName {
    return this.#typeName;
  }

  abstract insert(entries: readonly TimeSeriesEntry<GTypeName>[]): void;

  push(time: number, value: InferTimeSeriesType<GTypeName>): void {
    this.insert([{ time, value }]);
  }

  abstract select(options?: TimeSeriesSelectOptions): TimeSeriesEntry<GTypeName>[];

  abstract delete(options?: TimeSeriesDeleteOptions): void;

  aggregate(
    options: TimeSeriesAggregateOptions,
    aggregator: TimeSeriesAggregator<GTypeName>,
  ): AggregatedTimeSeriesEntry<GTypeName> | null {
    const { from, to, replace } = normalizeTimeSeriesAggregateOptions(options);

    const entries: readonly TimeSeriesEntry<GTypeName>[] = this.select({ from, to, asc: true });

    if (entries.length <= 1) {
      return null;
    }

    const aggregatedEntry: AggregatedTimeSeriesEntry<GTypeName> = aggregator(entries, { from, to });

    if (aggregatedEntry.from < from || aggregatedEntry.from > to) {
      throw new Error(
        `Invalid aggregated "from" range: ${aggregatedEntry.from}, expected: [${from}, ${to}] .`,
      );
    }

    if (aggregatedEntry.to < aggregatedEntry.from || aggregatedEntry.to > to) {
      throw new Error(
        `Invalid aggregated "to" range: ${aggregatedEntry.to}, expected: [${aggregatedEntry.from}, ${to}] .`,
      );
    }

    if (replace) {
      this.delete({ from: aggregatedEntry.from, to: aggregatedEntry.to - 1 });
      this.insert([
        {
          time: aggregatedEntry.from,
          value: aggregatedEntry.value,
        },
      ]);
    }

    return aggregatedEntry;
  }

  aggregateAverage(
    options: TimeSeriesAggregateOptions,
  ): AggregatedTimeSeriesEntry<GTypeName> | null {
    if (this.typeName !== 'int64' && this.typeName !== 'float64') {
      throw new Error(`Invalid type: ${this.typeName}.`);
    }

    return this.aggregate(
      options,
      (entries: readonly TimeSeriesEntry<GTypeName>[]): AggregatedTimeSeriesEntry<GTypeName> => {
        const from: number = entries[0].time;
        const to: number = entries[entries.length - 1].time;
        let value: number = 0;
        let totalDuration: number = 0;

        for (let i: number = 0, l: number = entries.length - 1; i < l; i++) {
          const entryA: TimeSeriesEntry<GTypeName> = entries[i];
          const entryB: TimeSeriesEntry<GTypeName> = entries[i + 1];
          const duration: number = entryB.time - entryA.time;
          value += entryA.value * duration;
          totalDuration += duration;
        }

        value /= totalDuration;

        if (this.typeName === 'int64') {
          value = Math.round(value);
        }

        return {
          from,
          to,
          value,
        };
      },
    );
  }

  aggregateConcat({
    separator = '\n',
    ...options
  }: TimeSeriesAggregateConcatOptions): AggregatedTimeSeriesEntry<GTypeName> | null {
    if (this.typeName !== 'text') {
      throw new Error(`Invalid type: ${this.typeName}.`);
    }

    return this.aggregate(
      options,
      (entries: readonly TimeSeriesEntry<GTypeName>[]): AggregatedTimeSeriesEntry<GTypeName> => {
        const from: number = entries[0].time;
        const to: number = entries[entries.length - 1].time;
        let value: string = '';

        for (let i: number = 0; i < entries.length; i++) {
          if (i !== 0) {
            value += separator;
          }
          value += entries[i].value;
        }

        return {
          from,
          to,
          value,
        };
      },
    );
  }

  abstract drop(): void;

  abstract [Symbol.dispose](): void;
}

import { isResultOk, type Result, tryAsyncFnc } from '@xstd/enum';
import { Path, type PathInput } from '@xstd/path';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import {
  NumberTimeSeries,
  type NumberTimeSeriesEntry,
} from '../../sub-types/number/number-time-series.ts';
import { type TimeSeriesDeleteOptions } from '../../types/methods/delete/time-series-delete-options.ts';
import { type TimeSeriesSelectOptions } from '../../types/methods/select/time-series-select-options.ts';
import { normalizedPartialTimeSeriesTimeRange } from '../../types/time-range/normalized-partial-time-series-time-range.ts';
import type { TimeSeriesTimeRange } from '../../types/time-range/time-series-time-range.ts';
import { sortTimeSeriesEntries } from '../../types/time-series-entry/sort-time-series-entries.ts';

/* FUNCTIONS */

const QX_TIME_BUCKET_DATA_VIEW = new DataView(new ArrayBuffer(8));

function f64_to_hex_string(input: number): string {
  QX_TIME_BUCKET_DATA_VIEW.setFloat64(0, input, true);
  let output: string = '';

  for (let i: number = 0; i < 8; i += 1) {
    output += QX_TIME_BUCKET_DATA_VIEW.getUint8(i).toString(16).padStart(2, '0');
  }

  return output;
}

function hex_string_to_f64(input: string): number {
  if (input.length !== 16) {
    throw new Error(`Invalid input length: ${input.length}, expected: 16.`);
  }

  for (let i: number = 0, j: number = 0; i < 8; i += 1, j += 2) {
    QX_TIME_BUCKET_DATA_VIEW.setUint8(i, Number(`0x${input.slice(j, j + 2)}`));
  }

  return QX_TIME_BUCKET_DATA_VIEW.getFloat64(0, true);
}

/* CONSTANTS */

const QX_TIME_BUCKET_TIME_BYTE_LENGTH = 8;
const QX_TIME_BUCKET_VALUE_BYTE_LENGTH = 8;
const QX_TIME_BUCKET_ENTRY_BYTE_LENGTH =
  QX_TIME_BUCKET_TIME_BYTE_LENGTH + QX_TIME_BUCKET_VALUE_BYTE_LENGTH;

/* TYPES */

export interface QxTimeBucketFlushOptions {
  readonly unload?: boolean;
}

/* CLASS */

export interface QxTimeBucketOptions extends TimeSeriesTimeRange {
  readonly dirPath: PathInput;
  readonly unloadTime?: number;
}

export class QxTimeBucket extends NumberTimeSeries {
  static timeSeriesTimeRangeToFileName({ from, to }: TimeSeriesTimeRange): string {
    return `${f64_to_hex_string(from)}-${f64_to_hex_string(to)}.bucket`;
  }

  static fileNameToTimeSeriesTimeRange(input: string): TimeSeriesTimeRange {
    const match: RegExpExecArray | null = /^([0-9a-f]{16})-([0-9a-f]{16})\.bucket$/.exec(input);
    if (match === null) {
      throw new Error(`Invalid input: ${input}`);
    }

    return {
      from: hex_string_to_f64(match[1]),
      to: hex_string_to_f64(match[2]),
    };
  }

  static readonly sortFnc = (a: QxTimeBucket, b: QxTimeBucket): number => {
    return a.from - b.from;
  };

  static fromFilePath(
    filePath: PathInput,
    options?: Omit<QxTimeBucketOptions, 'dirPath' | 'from' | 'to'>,
  ): QxTimeBucket {
    filePath = Path.of(filePath);
    return new QxTimeBucket({
      ...options,
      dirPath: filePath.dirname(),
      ...QxTimeBucket.fileNameToTimeSeriesTimeRange(filePath.basename()),
    });
  }

  readonly #path: Path;

  readonly #from: number;
  readonly #to: number;
  readonly #unloadTime: number;

  #buffer: ArrayBuffer | undefined;
  #view: DataView<ArrayBuffer> | undefined;
  #bytes: Uint8Array<ArrayBuffer> | undefined;
  #byteLength: number;

  #queue: Promise<any>;

  #unloadTimer: any;
  #requireFlush: boolean;

  constructor({ dirPath, from, to, unloadTime = 5000 }: QxTimeBucketOptions) {
    super();

    this.#path = Path.of(dirPath).concat(QxTimeBucket.timeSeriesTimeRangeToFileName({ from, to }));

    this.#from = from;
    this.#to = to;
    this.#unloadTime = unloadTime;

    this.#byteLength = 0;

    this.#queue = Promise.resolve();

    this.#requireFlush = false;
  }

  get from(): number {
    return this.#from;
  }

  get to(): number {
    return this.#to;
  }

  get byteLength(): number {
    return this.#byteLength;
  }

  #run<GReturn>(task: () => PromiseLike<GReturn> | GReturn): Promise<GReturn> {
    return (this.#queue = this.#queue.then(task, task));
  }

  /* DATA LOAD/SAVE */

  #setBuffer(buffer: ArrayBuffer, byteOffset?: number, byteLength?: number): void {
    this.#buffer = buffer;
    this.#view = new DataView(buffer, byteOffset, byteLength);
    this.#bytes = new Uint8Array(buffer, byteOffset, byteLength);
  }

  async #load(): Promise<void> {
    if (this.#buffer === undefined) {
      const result: Result<Uint8Array<ArrayBuffer>> = await tryAsyncFnc<
        [string],
        Uint8Array<ArrayBuffer>
      >(readFile, this.#path.toString());

      if (isResultOk(result)) {
        const bytes: Uint8Array<ArrayBuffer> = result.value;
        this.#setBuffer(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        this.#byteLength = bytes.byteLength;
      } else {
        if ((result.error as any).code === 'ENOENT') {
          this.#setBuffer(
            new ArrayBuffer(0x100, {
              maxByteLength: 0x100000000,
            }),
          );
          this.#byteLength = 0;
        } else {
          throw result.error;
        }
      }
    }

    clearTimeout(this.#unloadTimer);

    this.#unloadTimer = setTimeout((): void => {
      this.#unloadTimer = undefined;
      this.flush({ unload: true }).catch(reportError);
    }, this.#unloadTime);
  }

  #unload(): void {
    this.#buffer = undefined;
    this.#bytes = undefined;
    this.#view = undefined;
    this.#byteLength = 0;
  }

  #resize(extraByteLength: number): number {
    console.assert(this.#buffer !== undefined);

    const currentByteLength: number = this.#byteLength;
    const nextByteLength: number = currentByteLength + extraByteLength;

    if (this.#buffer!.resizable) {
      if (nextByteLength > this.#buffer!.maxByteLength) {
        throw new Error('Size limit reached.');
      }

      if (nextByteLength > this.#buffer!.byteLength) {
        this.#buffer!.resize(
          Math.min(this.#buffer!.maxByteLength, getOptimalBufferLength(nextByteLength)),
        );
      }
    } else {
      if (nextByteLength > this.#buffer!.byteLength) {
        const maxByteLength: number = 0x100000000;
        const nextBuffer: ArrayBuffer = new ArrayBuffer(
          Math.min(maxByteLength, getOptimalBufferLength(nextByteLength)),
          {
            maxByteLength,
          },
        );
        const currentBytes: Uint8Array = this.#bytes!;
        this.#setBuffer(nextBuffer);
        this.#bytes!.set(currentBytes);
      }
    }

    this.#byteLength = nextByteLength;

    return currentByteLength;
  }

  /* DATA READ/WRITE */

  #getTime(entryByteOffset: number): number {
    return this.#view!.getFloat64(entryByteOffset, true);
  }

  #setTime(entryByteOffset: number, time: number): void {
    this.#view!.setFloat64(entryByteOffset, time, true);
  }

  #getValue(entryByteOffset: number): number {
    return this.#view!.getFloat64(entryByteOffset + QX_TIME_BUCKET_TIME_BYTE_LENGTH, true);
  }

  #setValue(entryByteOffset: number, value: number): void {
    this.#view!.setFloat64(entryByteOffset + QX_TIME_BUCKET_TIME_BYTE_LENGTH, value, true);
  }

  #getInsertionByteOffset(time: number): number {
    console.assert(this.#view !== undefined);

    if (this.#byteLength === 0) {
      return 0;
    } else {
      const lastEntryByteOffset: number = this.#byteLength - QX_TIME_BUCKET_ENTRY_BYTE_LENGTH;

      if (time >= this.#getTime(lastEntryByteOffset) /* lastTime*/) {
        // insert at the end
        return this.#byteLength;
      } else if (time <= this.#getTime(0) /* firstTime */) {
        // insert at the beginning
        return 0;
      } else {
        // binary search
        let low: number = 0;
        let high: number = this.#byteLength >>> 4; // (/ 16)

        while (low <= high) {
          const mid: number = Math.floor((low + high) / 2);
          const midEntryByteOffset: number = mid << 4; // (* 16)
          const midTime: number = this.#getTime(midEntryByteOffset);

          if (midTime === time) {
            low = mid;
            break;
          } else if (midTime < time) {
            low = mid + 1;
          } else {
            high = mid - 1;
          }
        }

        return low << 4; // (* 16)
      }
    }
  }

  #getTimeRangeByteOffsets({ from, to }: TimeSeriesTimeRange): TimeSeriesTimeRange {
    let fromEntryByteOffset: number = this.#getInsertionByteOffset(from);
    while (
      fromEntryByteOffset >= QX_TIME_BUCKET_ENTRY_BYTE_LENGTH &&
      from === this.#getTime(fromEntryByteOffset - QX_TIME_BUCKET_ENTRY_BYTE_LENGTH)
    ) {
      fromEntryByteOffset -= QX_TIME_BUCKET_ENTRY_BYTE_LENGTH;
    }

    let toEntryByteOffset: number = this.#getInsertionByteOffset(to);
    const last: number = this.#byteLength - QX_TIME_BUCKET_ENTRY_BYTE_LENGTH;
    while (
      toEntryByteOffset <= last &&
      to === this.#getTime(fromEntryByteOffset + QX_TIME_BUCKET_ENTRY_BYTE_LENGTH)
    ) {
      toEntryByteOffset += QX_TIME_BUCKET_ENTRY_BYTE_LENGTH;
    }

    return {
      from: fromEntryByteOffset,
      to: toEntryByteOffset,
    };
  }

  #pushRaw(time: number, value: number): void {
    console.assert(this.#from <= time && time < this.#to);
    console.assert(this.#view !== undefined);
    console.assert(this.#bytes !== undefined);

    const insertByteOffset: number = this.#getInsertionByteOffset(time);

    this.#resize(QX_TIME_BUCKET_ENTRY_BYTE_LENGTH); // [f64, f64]
    this.#bytes!.copyWithin(
      insertByteOffset + QX_TIME_BUCKET_ENTRY_BYTE_LENGTH,
      insertByteOffset,
      this.#byteLength,
    );
    this.#setTime(insertByteOffset, time);
    this.#setValue(insertByteOffset, value);
  }

  #validateTime(time: number): void {
    if (time < this.#from || time >= this.#to) {
      throw new Error(`Invalid time: ${time}, expected: [${this.#from}, ${this.#to}[.`);
    }
  }

  /* OPERATIONS */

  override push(time: number, value: number): Promise<void> {
    return this.#run(async (): Promise<void> => {
      this.#validateTime(time);
      await this.#load();
      this.#pushRaw(time, value);
      this.#requireFlush = true;
    });
  }

  override insert(entries: NumberTimeSeriesEntry[]): Promise<void> {
    return this.#run(async (): Promise<void> => {
      if (entries.length === 0) {
        return;
      }

      entries.sort(sortTimeSeriesEntries);

      await this.#load();

      for (let i: number = 0; i < entries.length; i += 1) {
        const { time, value } = entries[i];
        this.#validateTime(time);
        this.#pushRaw(time, value);
      }

      this.#requireFlush = true;
    });
  }

  override select({ asc = true, ...options }: TimeSeriesSelectOptions = {}): Promise<
    readonly NumberTimeSeriesEntry[]
  > {
    return this.#run(async (): Promise<readonly NumberTimeSeriesEntry[]> => {
      const { from, to } = normalizedPartialTimeSeriesTimeRange(options);

      if (from >= this.#to || to < this.#from) {
        return [];
      }

      await this.#load();

      const { from: fromEntryByteOffset, to: toEntryByteOffset } = this.#getTimeRangeByteOffsets({
        from,
        to,
      });

      const entries: NumberTimeSeriesEntry[] = new Array(
        (toEntryByteOffset - fromEntryByteOffset) >>> 4 /* (/16) */,
      );

      if (asc) {
        for (
          let entryIndex: number = 0, entryByteOffset: number = fromEntryByteOffset;
          entryIndex < entries.length;
          entryIndex += 1, entryByteOffset += QX_TIME_BUCKET_ENTRY_BYTE_LENGTH
        ) {
          entries[entryIndex] = {
            time: this.#getTime(entryByteOffset),
            value: this.#getValue(entryByteOffset),
          };
        }
      } else {
        for (
          let entryIndex: number = 0, entryByteOffset: number = toEntryByteOffset;
          entryIndex < entries.length;
          entryIndex += 1, entryByteOffset -= QX_TIME_BUCKET_ENTRY_BYTE_LENGTH
        ) {
          entries[entryIndex] = {
            time: this.#getTime(entryByteOffset),
            value: this.#getValue(entryByteOffset),
          };
        }
      }

      return entries;
    });
  }

  override delete(_options?: TimeSeriesDeleteOptions): Promise<void> {
    return this.#run(async (): Promise<void> => {
      // const { from, to } = normalizedPartialTimeSeriesTimeRange(options);
      throw 'TODO';
    });
  }

  override drop(): Promise<void> {
    return this.#run(async (): Promise<void> => {
      await rm(this.#path.toString(), {
        force: true,
      });
      this.#unload();
    });
  }

  /* FLUSH */

  flush({ unload = false }: QxTimeBucketFlushOptions = {}): Promise<void> {
    return this.#run(async (): Promise<void> => {
      if (this.#requireFlush) {
        await mkdir(this.#path.dirname().toString(), {
          recursive: true,
        });
        await writeFile(this.#path.toString(), this.#bytes!.subarray(0, this.#byteLength));
        this.#requireFlush = false;

        if (unload) {
          this.#unload();
        }
      }
    });
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.flush({ unload: true });
  }
}

/* FUNCTIONS */

function getOptimalBufferLength(length: number): number {
  return (
    (1 <<
      Math.ceil(
        Math.log2(length) /* number of bytes to store the data */ +
          0.5 /* adds a "half-byte" of margin */,
      )) /* round to the upper limit */ >>>
    0
  );
}

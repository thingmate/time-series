import { Path, type PathInput } from '@xstd/path';
import { mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import {
  NumberTimeSeries,
  type NumberTimeSeriesEntry,
} from '../../sub-types/number/number-time-series.ts';
import { type TimeSeriesDeleteOptions } from '../../types/methods/delete/time-series-delete-options.ts';
import { normalizeTimeSeriesSelectOptions } from '../../types/methods/select/normalized-time-series-select-options.ts';
import { type TimeSeriesSelectOptions } from '../../types/methods/select/time-series-select-options.ts';
import { sortTimeSeriesEntries } from '../../types/time-series-entry/sort-time-series-entries.ts';
import { QxTimeBucket } from './qx-time-bucket.ts';

interface QxTimeSeriesConfig<GVersion extends number> {
  readonly version: GVersion;
}

interface QxTimeSeriesConfigV1 extends QxTimeSeriesConfig<1> {}

interface QxTimeSeriesOptions {
  readonly bucketsPath: Path;
  readonly buckets: QxTimeBucket[];
}

const QX_TIME_SERIES_TIME_INTERVAL = 512;

export class QxTimeSeries extends NumberTimeSeries {
  static async #loadConfig(configPath: Path): Promise<QxTimeSeriesConfigV1> {
    try {
      // TODO validate config file format/schema
      return JSON.parse(await readFile(configPath.toString(), { encoding: 'utf8' }));
    } catch (error: unknown) {
      if ((error as any).code === 'ENOENT') {
        const config: QxTimeSeriesConfigV1 = {
          version: 1,
        };
        await mkdir(configPath.dirname().toString(), { recursive: true });
        await writeFile(configPath.toString(), JSON.stringify(config), { encoding: 'utf8' });
        return config;
      } else {
        throw error;
      }
    }
  }

  static async #loadBuckets(bucketsPath: Path): Promise<QxTimeBucket[]> {
    try {
      return (await readdir(bucketsPath.toString()))
        .map((fileName: string): QxTimeBucket => {
          return QxTimeBucket.fromFilePath(bucketsPath.concat(fileName));
        })
        .sort(QxTimeBucket.sortFnc);
    } catch (error: unknown) {
      if ((error as any).code === 'ENOENT') {
        return [];
      } else {
        throw error;
      }
    }
  }

  static async open(dirPath: PathInput): Promise<QxTimeSeries> {
    dirPath = Path.of(dirPath);

    const bucketsPath: Path = dirPath.concat('buckets');

    const [config, buckets] = await Promise.all([
      this.#loadConfig(dirPath.concat('qx.config.json')),
      this.#loadBuckets(bucketsPath),
    ]);

    return new QxTimeSeries({
      ...config,
      bucketsPath,
      buckets,
    });
  }

  readonly #bucketsPath: Path;
  readonly #buckets: QxTimeBucket[]; // sorted list of buckets

  #queue: Promise<any>;

  private constructor({ bucketsPath, buckets }: QxTimeSeriesOptions) {
    super();

    this.#bucketsPath = bucketsPath;
    this.#buckets = buckets;

    this.#queue = Promise.resolve();
  }

  #run<GReturn>(task: () => PromiseLike<GReturn> | GReturn): Promise<GReturn> {
    return (this.#queue = this.#queue.then(task, task));
  }

  #getBucket(time: number): QxTimeBucket {
    const from: number =
      Math.floor(time / QX_TIME_SERIES_TIME_INTERVAL) * QX_TIME_SERIES_TIME_INTERVAL;
    const to: number = from + QX_TIME_SERIES_TIME_INTERVAL;

    const fileName: string = QxTimeBucket.timeSeriesTimeRangeToFileName({
      from,
      to,
    });

    let bucket: QxTimeBucket | undefined = this.#buckets.get(fileName);

    if (bucket === undefined) {
      bucket = new QxTimeBucket({
        dirPath: this.#bucketsPath,
        from,
        to,
      });
      this.#buckets.set(fileName, bucket);
    }

    return bucket;
  }

  /* OPERATIONS */

  override push(time: number, value: number): Promise<void> {
    return this.#run(async (): Promise<void> => {
      await this.#getBucket(time).push(time, value);
    });
  }

  override insert(entries: NumberTimeSeriesEntry[]): Promise<void> {
    return this.#run((): Promise<void> | void => {
      if (entries.length === 0) {
        return;
      }

      return concurrentPromises(
        entries
          .sort(sortTimeSeriesEntries)
          .map(({ time, value }: NumberTimeSeriesEntry): Promise<void> => {
            return this.#getBucket(time).push(time, value);
          }),
      );
    });
  }
  override select(options?: TimeSeriesSelectOptions): Promise<readonly NumberTimeSeriesEntry[]> {
    return this.#run(async (): Promise<readonly NumberTimeSeriesEntry[]> => {
      const { asc, from, to } = normalizeTimeSeriesSelectOptions(options);

      // TODO optimize by pre-sorting the buckets
      this.#buckets
        .values()
        .filter((bucket: QxTimeBucket): boolean => {
          // return (from <= bucket.from && bucket.from < to) || (from < bucket.to && bucket.to <= to);
          return bucket.to > from && bucket.from <= to;
        })
        .map((bucket: QxTimeBucket): void => {});

      console.log(options);
      throw 'TODO';
    });
  }

  override delete(_options?: TimeSeriesDeleteOptions): Promise<void> {
    return this.#run(async (): Promise<void> => {
      // const { from, to } = normalizedPartialTimeSeriesTimeRange(options);
      throw 'TODO';
    });
  }

  override drop(): Promise<void> {
    return this.#run(async (): Promise<void> => {
      await rm(this.#bucketsPath.toString(), { force: true, recursive: true });
      this.#buckets.clear();
    });
  }

  /* FLUSH */

  flush(): Promise<void> {
    return this.#run((): Promise<void> => {
      return concurrentPromises(
        this.#buckets.values().map((bucket: QxTimeBucket): Promise<void> => {
          return bucket.flush();
        }),
      );
    });
  }

  [Symbol.asyncDispose](): Promise<void> {
    return this.flush();
  }
}

/* FUNCTIONS */

// async function concurrently<GArguments extends unknown[]>(
//   promiseFactories: Iterable<(...args: GArguments) => PromiseLike<any> | any>,
//   ...args: GArguments
// ): Promise<void> {
//   return concurrentPromises(
//     Array.from(promiseFactories, (factory: (...args: GArguments) => PromiseLike<any> | any) => {
//       return Promise.try(factory, ...args);
//     }),
//   );
// }

async function concurrentPromises(promises: Iterable<PromiseLike<any>>): Promise<void> {
  const errors: readonly PromiseRejectedResult[] = (await Promise.allSettled(promises)).filter(
    (result: PromiseSettledResult<void>): result is PromiseRejectedResult => {
      return result.status === 'rejected';
    },
  );

  if (errors.length === 1) {
    throw errors[0].reason;
  } else if (errors.length > 1) {
    throw new AggregateError(
      errors.map((error: PromiseRejectedResult): unknown => {
        return error.reason;
      }),
    );
  }
}
